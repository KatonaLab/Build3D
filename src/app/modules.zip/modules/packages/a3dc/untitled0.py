# -*- coding: utf-8 -*-
"""
Created on Mon Apr 15 15:15:53 2019

@author: pongor.csaba
"""
import numpy as np

a=np.array([250,254,254,254])
min_value = np.iinfo(a.dtype).min
max_value = np.iinfo(a.dtype).max
print(a.dtype)
print(min_value)
print(max_value)


print(a)
b=a.astype(np.int16) #, casting='safe'
print(b)