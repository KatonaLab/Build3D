
from .ImageClass import ImageClass

__version__ = '0.1.0'
__author__ = 'Csaba István Pongor <csaba.pongor@gmail.com>'
__all__ = ['ImageClass']