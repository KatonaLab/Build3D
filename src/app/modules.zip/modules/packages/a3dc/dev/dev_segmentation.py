
import numpy as np
import SimpleITK as sitk


###############################################################################
##############################Preprocessing####################################
###############################################################################
def create_surfaceImage2D(ndarray):

    # Convert nd array to itk image
    itk_image = sitk.GetImageFromArray(ndarray)
    pixel_type = itk_image.GetPixelID()
    # Run binary threshold
    thresholded_itk_img = sitk.BinaryThreshold(itk_image, 0, 0, 0, 1)

    # Create an parametrize instance ofBinaryContourImageFilter()
    itk_filter = sitk.BinaryContourImageFilter()
    itk_filter.SetFullyConnected(False)
    #Execute to get a surface mask
    output = itk_filter.Execute(thresholded_itk_img)

    # Change pixel_type of the object map to be the same as the input image
    caster = sitk.CastImageFilter()
    caster.SetOutputPixelType(pixel_type)
    output=caster.Execute(output)*itk_image

    return (sitk.GetArrayFromImage(output)>0).astype(np.uint8)

def smoothingGaussianFilter(image, sigma):

    itk_img = sitk.GetImageFromArray(image)
    pixel_type = itk_img.GetPixelID()

    sGaussian = sitk.SmoothingRecursiveGaussianImageFilter()
    sGaussian.SetSigma(float(sigma))
    itk_img = sGaussian.Execute(itk_img)

    caster = sitk.CastImageFilter()
    caster.SetOutputpixel_type(pixel_type)

    return sitk.GetArrayFromImage(caster.Execute(itk_img))


def discreteGaussianFilter(image, sigma):
    itk_img = sitk.GetImageFromArray(image)
    pixel_type = itk_img.GetPixelID()

    dGaussian = sitk.DiscreteGaussianImageFilter ()
    dGaussian.SetVariance(int(sigma))
    dGaussian.SetUseImageSpacing(False)
    itk_img = dGaussian.Execute(itk_img)

    caster = sitk.CastImageFilter(itk_img)
    caster.SetOutputpixel_type(pixel_type)

    return sitk.GetArrayFromImage(caster.Execute(itk_img))


def medianFilter(image, radius):
    itk_img = sitk.GetImageFromArray(image)
    pixel_type = itk_img.GetPixelID()

    median = sitk.MedianImageFilter()
    median.SetRadius(int(radius))
    itk_img = median.Execute(itk_img)

    caster = sitk.CastImageFilter(itk_img)
    caster.SetOutputpixel_type(pixel_type)

    return sitk.GetArrayFromImage(caster.Execute(itk_img))


def regionGrowingSegmentation(image, seedList, initialNeighborhoodRadius=2, multiplier=2.5, NbrOfIterations=5,
                              replaceValue=255):
    itk_img = sitk.GetImageFromArray(image)


    filter = sitk.ConfidenceConnectedImageFilter()
    filter.SetSeedList(seedList)
    filter.SetMultiplier(multiplier)
    filter.SetNumberOfIterations(NbrOfIterations)
    filter.SetReplaceValue(replaceValue)
    filter.SetInitialNeighborhoodRadius(initialNeighborhoodRadius)
    itk_img = filter.Execute(itk_img)


    return sitk.GetArrayFromImage(itk_img)