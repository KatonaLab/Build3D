import unittest
import numpy as np
import time
import io
import sys

from tests_utils import from_idle
from context import segmentation
import assets_segmentation



class SegmentationTest(unittest.TestCase):
    
    
    def setUp(self):

        #self.__start = time.time()
        self.__count=0
        
        #Redirest stderr to dummy stream
        #Some SimpleITK functions output warnings to stderr
        #Store original stream in self.__stderr
        self.__stderr= sys.stderr
       
        sys.stderr = io.StringIO()
        
        #if from_idle:
            #print('Running: {}'.format(self.id()))
            #print('{} ({}s)'.format(self.id(), round(elapsed, 2))) 
        
    def tearDown(self):
        #elapsed = time.time() - self.__start
        
        #if from_idle:
            #print('\tFinished {} cases in {}s\n'.format(self.__count, round(elapsed, 10)))
        
        #Return stderr to original stream
        sys.stderr = self.__stderr
        
        
    def test_tag_image(self):
        
        for idx, cs in enumerate(assets_segmentation.tag_image_case_list):
            
            self.__count=self.__count+1
            
            output_array=segmentation.tag_image(cs['input'])
            result_array=cs['result']
            

            case_text="Case "+str(idx)
            
            #Test if data types are equal
            with self.subTest():
                self.assertEqual(output_array.dtype,  result_array.dtype, msg=case_text) 
            
            #Test if array values are equal
            #If data type is float use assert_almost_equal or assert_allclose
            with self.subTest():
                np.testing.assert_array_equal(output_array,result_array, verbose=True,err_msg=case_text)        
        

    def test_overlap_image(self):
    
        
        for idx, cs in enumerate(assets_segmentation.overlap_image_case_list):
            
            self.__count=self.__count+1
            
            output_array=segmentation.overlap_image(cs['input'])
            result_array=cs['result']
            

            case_text="Case "+str(idx)
            
            #Test if data types are equal
            with self.subTest():
                self.assertEqual(output_array.dtype,  result_array.dtype, msg=case_text) 
            
            #Test if array values are equal
            #If data type is float use assert_almost_equal or assert_allclose
            with self.subTest():
                np.testing.assert_array_equal(output_array,result_array, verbose=True,err_msg=case_text) 

        
    def test_threshold_manual(self):
    
    

        for idx, cs in enumerate(assets_segmentation.threshold_manual_case_list):
            
            self.__count=self.__count+1
            
            output_array=segmentation.threshold_manual(cs['input'], upper=cs['upper'], lower=cs['lower'])
            result_array=cs['result']
            

            case_text="Case "+str(idx)+" with upper="+str(cs['upper'])+" lower="+str(cs['lower'])
            
            #Test if data types are equal
            with self.subTest():
                self.assertEqual(output_array.dtype,  result_array.dtype, msg=case_text) 
            
            #Test if array values are equal
            #If data type is float use assert_almost_equal or assert_allclose
            with self.subTest():
                np.testing.assert_array_equal(output_array,result_array, verbose=True,err_msg=case_text)
        

    def test_threshold_auto(self):
         
        
        for idx, cs in enumerate(assets_segmentation.threshold_auto_case_list):
            
            self.__count=self.__count+1
            
            case_text="Case "+str(idx+1)+" with method="+str(cs['method'])+" mode="+str(cs['mode'])
            
            output=segmentation.threshold_auto(cs['input'], method=cs['method'], mode=cs['mode'])
            
            #Test if data types are equal
            with self.subTest():
                self.assertEqual(output[0].dtype,  cs['result_array'].dtype, msg=case_text) 
            
            #Test if array values are equal
            #If data type is float use assert_almost_equal or assert_allclose
            

            with self.subTest():
                np.testing.assert_array_equal(output[0], cs['result_array'], verbose=True, err_msg=case_text)
            #Test if thresholds are equal
            with self.subTest():
                self.assertEqual(output[1], cs['result_threshold'], msg='Threshold values do not match '+case_text)                


    def test_threshold_adaptive(self):
        

  
        for idx, cs in enumerate(assets_segmentation.threshold_adaptive_case_list):
            
            self.__count=self.__count+1
            
            output_array=segmentation.threshold_adaptive(cs['input'], method=cs['method'], blocksize=cs['blocksize'], offset=cs['offset'])
            result_array=cs['result']
            

            case_text="Case "+str(idx)+" with method="+str(cs['method'])+" blocksize="+str(cs['blocksize'])+" offset="+str(cs['offset'])
            
            #Test if data types are equal
            with self.subTest():
                self.assertEqual(output_array.dtype,  result_array.dtype, msg=case_text) 
            
            #Test if array values are equal
            #If data type is float use assert_almost_equal or assert_allclose
            with self.subTest():
                np.testing.assert_array_equal(output_array,result_array, verbose=True,err_msg=case_text)
        
'''
if __name__ == '__main__':
'''        
    