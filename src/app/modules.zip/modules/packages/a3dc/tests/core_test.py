import unittest
import numpy as np
import time
import io
import sys

from context import core
from tests_utils import from_idle
import assets_core




class CoreTest(unittest.TestCase):
    
        
    def setUp(self):
        
        #self.__start = time.time()
        self.__count=0
        
        #Redirest stderr to dummy stream
        #Some SimpleITK functions output warnings to stderr
        #Store original stream in self.__stderr
        self.__stderr= sys.stderr
        sys.stderr = io.StringIO()
        
        #if from_idle:
            #print('Running: {}'.format(self.id()))

        
    def tearDown(self):
        
        #elapsed = time.time() - self.__start
        
        #if from_idle:
            #print('\tFinished {} cases in {}s\n'.format(self.__count, round(elapsed, 10)))
        
        #Return stderr to original stream
        sys.stderr = self.__stderr
        
        
    def test_analyze(self):
         
        
        for idx, cs in enumerate(assets_core.analyze_case_list):
            
            
            case_text="Case "+str(idx+1)+" with "
            self.__count=self.__count+1
            
            #Settings
            if cs['settings']==None:
                case_text=case_text+'Default settings'
            else:
                for key in cs['settings']:
                    case_text+=' '+str(key)+' = '+str(cs['settings'][key])
            
            if cs['settings']!=None:
                output =core.analyze(cs['input'], **cs['settings'] )
            
            else:
                output =core.analyze(cs['input'])
            
            #Test if image data types are equal
            with self.subTest():
                self.assertEqual(output.image.dtype,  cs['result'].image.dtype, msg='Data type of image arrays do not match in '+case_text)
            
                
            #Test if image arrays are the same
            with self.subTest():
                np.testing.assert_array_equal(output.image,  cs['result'].image, verbose=True,err_msg='Image arrays do not match in '+case_text)
           
            #Test if image metadata are the same
            with self.subTest():
                self.assertDictEqual(output.metadata,  cs['result'].metadata, msg='Image metadata do not match in '+case_text)
            
            #Test if image database are the same
            with self.subTest():
                self.assertDictEqual(output.database,  cs['result'].database, msg='Image databases do not match in '+case_text) 



    def test_analyze_error(self):
        

        for idx, cs in enumerate(assets_core.analyze_error_case_list):
           
            with self.subTest():
                
                
                self.__count=self.__count+1
                
                #Has to be run within a context (using 'with') where the 
                #exception can be cought or with lambda function (acts like it's own context)
                #self.assertRaises(cs['result'], lambda:core.analyze(cs['input'], **cs['settings']))#lambda:func())
                #The following solution checks for text to be in message as well
                with self.assertRaises(Exception) as context:
                    
                        core.analyze(cs['input'], **cs['settings'])
          
                case_text="Case "+str(idx+1)+' with : '+str(context.exception)
                self.assertTrue(cs['message'] in str(context.exception), msg=case_text)
        
    def test_colocalization(self):
         
        
        for idx, cs in enumerate(assets_core.colocalization_case_list):
            
            self.__count=self.__count+1
            
            #Create list of analyzed images
            input_list=[ core.analyze(im) for im in cs['input']]

            #error message
            case_text="Case "+str(idx+1)+" with "
            
            #Settings
            if cs['settings']==None:
                case_text=case_text+'Default settings'
            else:
                for key in cs['settings']:
                    case_text+=' '+str(key)+' = '+str(cs['settings'][key])
            
            #Run tested function
            if cs['settings']!=None:
                output =core.colocalization(input_list, **cs['settings'] )
            
            else:
                output =core.colocalization(input_list)
                

            #
            images=[output[0]]+output[1]
            results=[cs['result'][0]]+cs['result'][1]
           
            #
            for i in range(len(images)):
                #Test if image data types are equal
                with self.subTest():
                    self.assertEqual(images[i].image.dtype,  results[i].image.dtype, msg='Data type of image arrays do not match in '+case_text)
                
                    
                #Test if image arrays are the same
                with self.subTest():
                    np.testing.assert_array_equal(images[i].image,  results[i].image, verbose=True,err_msg='Image arrays do not match in '+case_text)
               
                #Test if image metadata are the same
                with self.subTest():
                    self.assertDictEqual(images[i].metadata,  results[i].metadata, msg='Image metadata do not match in '+case_text)
                
                #Test if image database are the same
                with self.subTest():
                    self.assertDictEqual(images[i].database,  results[i].database, msg='Image databases do not match in '+case_text)                 

    def test_colocalization_error(self):
        
        
        for idx, cs in enumerate(assets_core.colocalization_error_case_list):
           
            with self.subTest():
                
                self.__count=self.__count+1
                
                #Has to be run within a context (using 'with') where the 
                #exception can be cought or with lambda function (acts like it's own context)
                #self.assertRaises(cs['result'], lambda:core.analyze(cs['input'], **cs['settings']))#lambda:func())
                #The following solution checks for text to be in message as well
                with self.assertRaises(Exception) as context:
                        core.colocalization(cs['input'], **cs['settings'])

                #error message 
                case_text="Case "+str(idx+1)+' with : '+str(context.exception)
                self.assertTrue(cs['message'] in str(context.exception), msg=case_text)
 
    def test_apply_filter(self):
         
        
        for idx, cs in enumerate(assets_core.apply_filter_case_list):
            
            self.__count=self.__count+1
            

            #error message
            case_text="case "+str(idx+1)
            
            #Run tested function
            output =core.apply_filter(cs['input'], **cs['settings'])

            #
            #images=[output[0]]+output[1]
            #results=[cs['result'][0]]+cs['result'][1]
           
            #Test if image data types are equal
            with self.subTest():
                self.assertEqual(cs['result'].image.dtype,  output.image.dtype, msg='Data type of image arrays do not match in '+case_text)
            
            #Test if image arrays are the same
            with self.subTest():
                np.testing.assert_array_equal(cs['result'].image,  output.image, verbose=True,err_msg='Image arrays do not match in '+case_text)
           
            #Test if image metadata are the same
            with self.subTest():
                self.assertDictEqual(cs['result'].metadata,  output.metadata, msg='Image metadata do not match in '+case_text)
            
            #Test if image database are the same
            with self.subTest():
                self.assertDictEqual(cs['result'].database,  output.database, msg='Image databases do not match in '+case_text)         
    
'''
if __name__ == '__main__':
    

    def format_string(string, color='green'):
        
        #Ansi Escap characers:
        ANSI_DICT={'close':'\u001b[0m', 'open':u'', 'underlined':'\u001b[4m', 'red':'\u001b[31m', 'green':'\u001b[32m'}
        
        if sys.stdout.isatty() and color in ANSI_DICT.keys():
            return string
            
        else:
            return ANSI_DICT["open"]+ANSI_DICT[color]+ANSI_DICT["underlined"]+string+ANSI_DICT["close"]
    
  
    def tag_image(img):
        
        tagged_array=segmentation.tag_image(img.get_3d_array())
    
        return VividImage(tagged_array, copy.deepcopy(img.metadata ))



   
    
    
    #img3=assets_core.apply_filter_input_1
    #img_analyzed_3=core.analyze(img3)
    
   
    filters=assets_core.apply_filter_settings_11
    img_filtered=core.apply_filter(assets_core.apply_filter_input_11, **filters)
    print('')
    print((img_filtered.image, None))
    print('')
    print(img_filtered.metadata)
    print('') 
    print(img_filtered.database)
    print('') 
    print(assets_core.apply_filter_input_11.database)    
    print('')     
'''    

      
    
 