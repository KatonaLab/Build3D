import sys
from gc import collect
import os

def from_idle():
    '''Check if script is running from command line. 
    
    TODO:Find more elegant solution!!
    '''
    
    #if isinstance(sys.argv[0], str):
        #return False
    #else:
        #return True
    if sys.stdout.isatty():
        return False
    else:
        return True 

def format_string(string, color='green'):
    '''Print string formatted to be underlined and set to color red or green 
    using ANSI escape characters. If output is attached to terminal print 
    unformatted string.
    
    TODO: Implement more formatting options and colors as needed
    '''
    
    #Ansi Escape characers:
    ANSI_DICT={'close':'\u001b[0m', 'open':u'', 'underlined':'\u001b[4m', 'red':'\u001b[31m', 'green':'\u001b[32m'}
    
    if sys.stdout.isatty() and color in ANSI_DICT.keys():
        return string
        
    else:
        return ANSI_DICT["open"]+ANSI_DICT[color]+ANSI_DICT["underlined"]+string+ANSI_DICT["close"]

def clear_memory():
    '''Clear non protected objects to make sure there are no clashes, while 
    running tests.
    '''
    
    #Clear non protected objects from memory
    for name in dir():
        if not name.startswith('_'):
            del globals()[name]
    
    for name in dir():
        if not name.startswith('_'):
            del locals()[name]
            
    #Run Garbage collection
    collect()

def clear_console():
    '''Clear console screen.
    '''
    #Clear console 'cls' for windows and clear for linux/OsX
    os.system('cls' if os.name=='nt' else 'clear')
    
