import sys
import io
import cProfile
import unittest
import pstats

from segmentation_test import SegmentationTest
from core_test import CoreTest
from tests_utils import from_idle, format_string
#from tests_utils import clear_console


###############################################################################
#Usage: Either using Python Shell or command line interface (cli):
#python -m unittest discover
#python tests.py
#python -m unittest discover tests

def formatted_run(test, separator=78*' '):
    '''Tun a test class with formatted output. Separator is used to structure
    output in console.
    '''
    
    
    print(format_string('\n'+separator+'\n'+test.__name__.center(len(separator))+'\n', color='red'))
    

    #Redirest stderr to dummy stream
    #Some SimpleITK functions output warnings to stderr
    original_stderr=sys.stderr
    sys.stderr = io.StringIO()


    #Run cProfiles without saving to files
    #Using cProfile.run('fun()') convention prints full report
    pr=cProfile.Profile()#
    pr.enable()
    
    test_suite = unittest.TestLoader().loadTestsFromTestCase(test)
    
    unittest.TestResult()
    test_stream=io.StringIO()
    
    test_result=unittest.TextTestRunner(stream=test_stream, verbosity=4).run(test_suite)
    
    pr.disable()

    #Create stream and generate profile stats report form profile
    s=io.StringIO()
    ps = pstats.Stats(pr, stream=s)
    
    #Format and sort stats report
    #Sort by cumulative time and only show results for functions containing 'tests'
    
    ps.strip_dirs().sort_stats('cumulative').print_stats('test' )
    
    #Print results
    print(format_string('\nTest Results:\n'))
    
    print(test_stream.getvalue())
        
    #Print formatted stats report
    print(format_string('\nProfile Report:\n'))
    print(s.getvalue())

    print(format_string(separator, color='red'))
    
    #Restor stderr
    sys.stderr=original_stderr
    
    return test_result.wasSuccessful()


if __name__ == '__main__':

    #Run formatted output if script is run from python shell
    if from_idle():
        test_list=[CoreTest, SegmentationTest]
        
        results=[]
        for test in test_list:   
            results.append(formatted_run(test))   
        
        
        separator=78*'_'
        print(format_string(separator, color='red'))
        print('')
        for idx, test in enumerate(test_list):    
            
            if results[idx]==True:
                print(format_string(str(idx+1)+'. '+test.__name__+' WAS SUCCESSFUL!'))
            else:
                print(format_string(test.__name__+' UNSUCCESSFUL!', color='red'))
        print(format_string(separator, color='red'))
        
    #Run simple test if called from command line    
    else:
        #clear_console()
        unittest.main()


      
    
 